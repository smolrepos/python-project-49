from brain_games.games.brain_gcd import main


if __name__ == '__main__':
    main()
