### Hexlet tests and linter status:
[![Actions Status](https://github.com/smolrepos/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/smolrepos/python-project-49/actions)
[![Maintainability](https://api.codeclimate.com/v1/badges/c2bf307ec79e8e57bb75/maintainability)](https://codeclimate.com/github/smolrepos/python-project-49/maintainability)

<a href="https://asciinema.org/a/O8mkEUn3UQgbAnP6teO4MMmVK" target="_blank"><img src="https://asciinema.org/a/O8mkEUn3UQgbAnP6teO4MMmVK.svg" /></a>