from brain_games.games.brain_calc import main


if __name__ == '__main__':
    main()
