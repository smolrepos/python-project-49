from brain_games.games.brain_even import main


if __name__ == '__main__':
    main()
