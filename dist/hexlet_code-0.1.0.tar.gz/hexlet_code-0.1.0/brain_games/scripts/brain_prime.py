from brain_games.games.brain_prime import main


if __name__ == '__main__':
    main()
